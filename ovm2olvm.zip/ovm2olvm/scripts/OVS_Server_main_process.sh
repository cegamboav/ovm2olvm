#!/usr/bin/env bash

# Name          : runApplication.sh
# Author        : carlos.gamboa@oracle.com
# Version       : 1.0
# Copyright     : GPLv2
# Description   : This script is used to start the migration process
# Usage         : ./runApplication.sh
#
# Disclaimer           :
#
#Keep in mind that this is not part of an Oracle solution, hence its customization is not supported.
#Oracle support is not responsible for maintaining, troubleshooting, nor supporting this script.
#
#If you consider this sample script suitable to be used as a solution but require customization, we rather recommend that you engage with Oracle ACS.
#
#Oracle Consulting Services, http://www.oracle.com/us/products/consulting/overview/index.html
#
############################################################
#Variables of the script:
log=''
status='0'
repository=''

process_vdisks(){
	
	if [ -f scripts/process_vdisks.sh ]
	then
		#Display the information to the customer
		echo '-----------------------------------'|tee -a $log
		echo "** Converting vdisks to qcow2 format..." |tee -a $log
		echo ''|tee -a $log
		status='0'
		status=$(/bin/bash scripts/process_vdisks.sh $target $log 1)
		if [ $status -eq 1 ]
		then
			echo "** Finishing the process from OVM perspective" |tee -a $log
			echo "** Connect the NFS File System to OLVM" |tee -a $log
			echo "** To continue the process." |tee -a $log
			echo "ok" > $target/status.txt
			else
			echo "** [Error]: Error converting the vdisks, finishing the script!!" |tee -a $log
		fi
	fi
}

choose_VMs(){
  if [ -f scripts/select_vms.sh ]
  then
    status='0'
    echo '-----------------------------------'|tee -a $log
    echo "** Start to Select the VMs to migrate..." |tee -a $log
    echo "  " |tee -a $log
    /bin/bash scripts/select_vms.sh $target $log
    status=$(cat /tmp/removed_vms.sts)
  fi
}

list_vms(){
  continue=0
  while [ $continue -eq 0 ]
  do
    echo ''>/tmp/ovm2olvm_vm_chosen.txt
    python scripts/print_VMs.py $target/ovm2olvm/json_files/VMs_info.json 0
    vm=$(cat /tmp/ovm2olvm_vm_chosen.txt)
    selected_option=$(echo $vm|grep 1|wc -l)
    if [ $selected_option -eq 1 ]
    then
      process_vdisks
      continue=1
    else
		selected_option=$(echo $vm|grep 2|wc -l)
		if [ $selected_option -eq 1 ]
		then
			echo "[Error] Error in the print_VMs.py script" >> $log
			continue=1
		else
			choose_VMs
		fi
    fi
  done

}

create_vms_json(){
  echo '** Calling function to create the JSON of the VM information ...' | tee -a $log
  status='0'
  if [ -f scripts/create_VMs_jsonFile.sh ]
  then
    status='0'
    status=$(/bin/bash scripts/create_VMs_jsonFile.sh $repository $target $log)
    #If the process ends correctly
    if [[ $status == '1' ]]
    then
      #call the list_vms function
      list_vms
    fi
  else
    echo "[Error]: File scripts/create_VMs_jsonFile.sh does not exist!!! Finishing program..."| tee -a $log
  fi
}

remove_target_data(){
  echo "** Removing target repository data!"| tee -a $log
  echo ""| tee -a $log
  rm -rf $target/*
  echo "[OK] Data removed from $target"| tee -a $log
  echo '---------------------------------------' |tee -a $log
}

compare_repositories(){
  echo '** Comparing zise of the file systems...'|tee -a $log
  echo ''|tee -a $log
  #Get the used space
  local_repo=$(df  |grep $repository|awk '{print $2}')
  #Get the available space:
  target_repo=$(df  |grep $target|awk '{print $3}')
  if [ $target_repo -ge $local_repo ]
  then
    echo "[OK] Target repository is equals or bigger than chosen repository."|tee -a $log
    echo "  Local Repository used space: $local_repo"|tee -a $log
    echo "  Target Repository available space: $target_repo"|tee -a $log
    echo '---------------------------------------' |tee -a $log
    create_vms_json
  else
    echo "[Error]: The choosen Repository is bigger than Target Repository."| tee -a $log
    echo "  Local Repository used space: $local_repo"|tee -a $log
    echo "  Target Repository available space: $target_repo"|tee -a $log
    remove_target_data
  fi
}

choose_repository(){
  echo '** Calling function to choose the local repository...' | tee -a $log
  if [ -f scripts/select_repository.py ]
  then
    echo ''>/tmp/ovm2olvm_repo_chosen.txt
    python scripts/select_repository.py $target/ovm2olvm/json_files/repositories.json
    repository=$(cat /tmp/ovm2olvm_repo_chosen.txt)
    echo ''| tee -a $log
    echo 'Chosen repository: '$repository| tee -a $log
    echo ''| tee -a $log
    if [ $repository == '' ]
    then
      echo "[Error]: The repository variable is empty!!!"
    else
      echo '[OK] Repository choosed correctly.' | tee -a $log
      echo '---------------------------------------' |tee -a $log
      compare_repositories
    fi
  else
    echo "[Error]: File scripts/select_repository.py does not exist!!! Finish program..."| tee -a $log
  fi
}

create_json_files(){
  echo '** Creating JSON files...' | tee -a $log
  status='0'
  #If the script exists
  if [ -f scripts/create_jsonFiles.sh ]
  then
	#call the create json file script
    status=$(/bin/bash scripts/create_jsonFiles.sh $target $log)
	#If the status is 1, all finish correctly
    if [[ $status == '1' ]]
    then
		#Show OK messge
      echo '[OK] JSON files created correctly.' | tee -a $log
      echo '---------------------------------------' |tee -a $log
	  #Call the choose repository script
      choose_repository
	#If not 
    else
		#show error message
      echo '[Error] Check the error message'| tee -a $log
    fi
	#if not 
  else
	#Show error message
    echo "[Error]: File scripts/create_jsonFiles.sh does not exist!!! Finish program..."| tee -a $log
  fi
}

create_target_structure(){
  #Now proceed to create the structure in the target repository:
  status='0'
  target="$(cat /tmp/target.txt)"
  #If the file exists
  if [ -f scripts/create_target_structure.sh ]
  then
	#Start the creation process:
    status=$(/bin/bash scripts/create_target_structure.sh $target $log)
	#If all goes fine continue with the script
    if [[ $status == '1' ]]
    then
	  #Call the function to create the json files
      create_json_files
    fi
	#If not
  else
	#Show error message
    echo "[Error]: File scripts/create_target_structure.sh does not exist!!! Finish program..."| tee -a $log
  fi
}

select_nfs(){
  status='0'
  #If the file exists
  if [ -f scripts/select_nfs.sh ]
  then
    #select an NFS from the customer:
    /bin/bash scripts/select_nfs.sh $log 0
    status="$(cat /tmp/status.txt)"
    #If status 1 means the NFS is okay
    if [[ $status == '1' ]]
    then
      create_target_structure
    fi
  #if not
  else
    #show error message
    echo "[Error]: File scripts/select_nfs.sh does not exist!!! Finishing program..."| tee -a $log
  fi
}

check_server(){
  status='0'
  echo '** Checking the OVS Server...'|tee -a $log
  echo ''|tee -a $log
  if [ -f scripts/general_review_ovsserver.sh ]
  then
    #Check the status of the OVS Server
    status=$(/bin/bash scripts/general_review_ovsserver.sh $log)
    #If all pass ok
    if [[ $status == '1' ]]
    then
	  #Call the function to select the NFS file system.
      select_nfs
    else
      echo "[Error]: Stopping the process!"| tee -a $log
    fi
  else
    echo "[Error]: File scripts/general_review_ovsserver.sh does not exist!!! Finishing program..."| tee -a $log
  fi
}

create_log_file(){
  status=$(/bin/bash scripts/create_log_file.sh)
  #If it was create correctly
  if [[ $status == '1' ]]
  then
    log=`cat /tmp/log_file.txt`
    echo "[OK] Log file created "$log |tee $log
    echo '-----------------------------------'| tee -a $log
    check_server
  else
    echo "[Error]: The log file was not able to be created..."| tee -a $log
    echo "Stopping the program!"| tee -a $log
    echo '-----------------------------------'| tee -a $log
  fi
}

OVS_Server(){
  clear
  #create the Log file
  if [ -f scripts/create_log_file.sh ]
  then
    echo "** Creating log file ..."
    echo ""
    create_log_file
  else
    echo "[Error]: File scripts/create_log_file.sh does not exist!!! Finishing program..."
  fi
}


OVS_Server
