#!/usr/bin/env bash

# Name          : create_vdisks_jsonFile.sh
# Author        : carlos.gamboa@oracle.com
# Version       : 1.0
# Copyright     : GPLv2
# Description   : This script is use to creat the json file of all the disks in the VMs
# Usage         : ./create_vdisks_jsonFile.sh
#
# Disclaimer           :
#
#Keep in mind that this is not part of an Oracle solution, hence its customization is not supported.
#Oracle support is not responsible for maintaining, troubleshooting, nor supporting this script.
#
#If you consider this sample script suitable to be used as a solution but require customization, we rather recommend that you engage with Oracle ACS.
#
#Oracle Consulting Services, http://www.oracle.com/us/products/consulting/overview/index.html
#
############################################################
#Variables in the script
#File name:
file_name=$1
#log file:
log=$2
#vm.cfg path
vm_path=$3
#number of vdisks proceed
num_vdisks=0
#Lists to pass the information to the mkJson script
disks_titles="$(echo "vdisk_id,vdisk_name,vdisk_device,vdisk_size,vdisk_path")"
disks_info="$(echo " ")"
same_repo=0

#function to check if the repository of the VM file and the vdisk is the same
check_same_repo(){
	same_repo=0
	#get the image path
	image_path="$(echo $disk_i|cut -d ':' -f2)"
	#Store the vm repository
	repo_vm="$(echo $vm_path|cut -d '/' -f4)"
	#Store the vdisk repository
	repo_disk="$(echo $image_path|cut -d '/' -f4)"
	#check if they are equals
	if [[ $repo_vm == $repo_disk ]]
	then
		same_repo=1
	fi
}

#function to get the disk name:
get_disk_name(){
	vdisk_name="$(python -m json.tool /OVS/Repositories/$repo_disk/.ovsmeta|grep $disk_file -A 2|grep SIMPLE_NAME|cut -d ':' -f 2|cut -d '"' -f 2|sed 's/ //g')"
	disks_info+=$vdisk_name','
}

#function to collect all the information:
run(){
	#Get the disks from the vm.cfg
	disks="$(grep 'disk =' $vm_path|cut -d '[' -f2|cut -d ']' -f 1)"
	i=0
	while [ $i -lt 1 ]
	do
		#get the vdisk file
		disk_i="$(echo $disks|cut -d ',' -f1)"
		#check if the file is a vdisk:
		ifvdisk="$(echo $disk_i|egrep '.img'|wc -l)"
		#if is a vdisk
		if [ $ifvdisk -eq 1 ]
		then
			check_same_repo
			if [ $same_repo == 1 ]
			then
				if [ -f $image_path ]
				then
					#get the vdisk image name
					disk_file="$(echo $image_path|cut -d '/' -f6)"
					echo '  Collecting data for vdisk: '$disk_file >> $log
					#insert the collected information
					disks_info+=$disk_file','
					get_disk_name
					device="$(echo $disks|cut -d ',' -f2)"
					disks_info+=$device','
					disks_info+=$(ls -lh /OVS/Repositories/$repo_disk/VirtualDisks/$disk_file|awk '{print $5}'|cut -d '.' -f 1|cut -d 'G' -f 1)
					disks_info+=','$image_path
					#check if there is more disks in the vm.cfg file
					disks="$(echo $disks|cut -d ',' -f4-)"
					#if not
					if [ -z "$disks" ]
					then
						#get out of the while
						i=1
					#if not
					else
						#just add a ,
						disks_info+=','
					fi
					#get the VM id
					vm_id="$(echo $vm_path |cut -d '/' -f6)"


					#If the file_name does not exist
					if [ -f $file_name ]
					then
						#call the script to create the json file
						/bin/bash scripts/mk_vdisk_json_file.sh $file_name 5 $disks_titles $disks_info $vm_id 1
					else
						#call the script to add an object
						/bin/bash scripts/mk_vdisk_json_file.sh $file_name 5 $disks_titles $disks_info $vm_id 0
					fi
					((num_vdisks++))
				
				else
					#Error message to the user
					echo "  [Error]: The vdisk: $image_path do not exist in the OVS Server!!!" >> $log
					#check if there is more disks in the vm.cfg file
					disks="$(echo $disks|cut -d ',' -f4-)"
					#if not
					#if $disks is empty
					if [ -z "$disks" ]
					then
						#get out of the while
						i=1
					fi
				fi
			else
				echo "Virtual disk is not in the same repository as the VM file"  >> $log
				i=1
			fi
		#if no skeep the disk:
		else
			echo '  ++ Skipping ISO/Physical Disk ...' >> $log
			disks="$(echo $disks|cut -d ',' -f4-)"
			if [ -z "$disks" ]
			then
				i=1
			fi
		fi
	done
	
		
	
	echo '' >> $log
}

run
echo $num_vdisks
