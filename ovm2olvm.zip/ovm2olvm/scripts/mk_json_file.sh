#!/usr/bin/env bash

# Name          : select_nfs.sh
# Author        : carlos.gamboa@oracle.com
# Version       : 1.0
# Copyright     : GPLv2
# Description   : This script is use to make the customer select an NFS file system to be used as target
#                 of the OLVM movement
# Usage         : ./select_nfs.sh
#
# Disclaimer           :
#
#Keep in mind that this is not part of an Oracle solution, hence its customization is not supported.
#Oracle support is not responsible for maintaining, troubleshooting, nor supporting this script.
#
#If you consider this sample script suitable to be used as a solution but require customization, we rather recommend that you engage with Oracle ACS.
#
#Oracle Consulting Services, http://www.oracle.com/us/products/consulting/overview/index.html
#
############################################################
#Variables of the funcion:
file_name="$(echo $1)"
num_parameters="$(echo $2)"
list_name="$(echo $3)"
col_names="$(echo $4)"
col_details="$(echo $5)"

log=$5

status=0
counter=0

#To get the status of the script
status=0

arr_names=()
arr_details=()

create_arrays(){
  IFS=',' read -ra ADDR <<< "$col_names"
  for i in "${ADDR[@]}"; do
      arr_names+=("$i")
  done

  IFS=',' read -ra ADDR <<< "$col_details"
  for i in "${ADDR[@]}"; do
      arr_details+=("$i")
  done
  status=1
}

create_jsonFile(){
  len=${#arr_details[@]}
  lines=$((len / num_parameters))
  detail+='{"'$list_name'" : [{'
  for (( i=0; i<$lines; i++ ))
  do
    for (( j=0; j<$num_parameters;j++ ))
    do
    	detail+='"'${arr_names[$j]}'":'
      if [ $j -eq $((num_parameters-1)) ]
      then
        detail+='"'${arr_details[$counter]}'"'
      else
        detail+='"'${arr_details[$counter]}'",'
      fi
      ((counter++))
    done
    if [ $i -lt $((lines-1)) ]
    then
      detail+='},{'
    else
      detail+='}]}'
      echo $detail > $file_name
    fi
  done
  status=1
}

create_arrays
if [ $status -eq 1 ]
then
  status=0
  create_jsonFile
  if [ $status -eq 1 ]
  then
    echo 1
  else
    echo 0
  fi
fi
#python -m json.tool $file_name
