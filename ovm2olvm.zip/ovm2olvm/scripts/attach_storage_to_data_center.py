import ovirtsdk4 as sdk
import ovirtsdk4.types as types
import os
import sys

manager_name=sys.argv[1]
pswd=sys.argv[2]
dc_1=sys.argv[3]

# Create the connection to the server:
connection = sdk.Connection(
    url='https://'+manager_name+'/ovirt-engine/api',
    username='admin@internal',
    password=pswd,
    ca_file='scripts/ca.pem',
)

# Locate the service that manages the storage domains and use it to
# search for the storage domain:
sds_service = connection.system_service().storage_domains_service()
sd = sds_service.list(search='name=mydata')[0]

# Locate the service that manages the data centers and use it to
# search for the data center:
dcs_service = connection.system_service().data_centers_service()
dc = dcs_service.list(search='name='+dc_1)[0]

# Locate the service that manages the data center where we want to
# attach the storage domain:
dc_service = dcs_service.data_center_service(dc.id)

# Locate the service that manages the storage domains that are attached
# to the data centers:
attached_sds_service = dc_service.storage_domains_service()

# Use the "add" method of service that manages the attached storage
# domains to attach it:
attached_sds_service.add(
    types.StorageDomain(
        id=sd.id,
    ),
)

# Wait until the storage domain is active:
attached_sd_service = attached_sds_service.storage_domain_service(sd.id)
while True:
    #time.sleep(5)
    os.system('sleep 5')
    sd = attached_sd_service.get()
    if sd.status == types.StorageDomainStatus.ACTIVE:
        f = open("/tmp/nfs_ds.txt", "a")
        f.write(str('1'))
        f.close()
        break


# Close the connection to the server:
connection.close()