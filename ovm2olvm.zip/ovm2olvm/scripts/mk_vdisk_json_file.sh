#!/usr/bin/env bash

# Name          : mk_vdisks_json_file.sh
# Author        : carlos.gamboa@oracle.com
# Version       : 1.0
# Copyright     : GPLv2
# Description   : This script is use to make the json file for the vdisks and vNICs
# Usage         : ./mk_vdisks_json_file.sh
#
# Disclaimer           :
#
#Keep in mind that this is not part of an Oracle solution, hence its customization is not supported.
#Oracle support is not responsible for maintaining, troubleshooting, nor supporting this script.
#
#If you consider this sample script suitable to be used as a solution but require customization, we rather recommend that you engage with Oracle ACS.
#
#Oracle Consulting Services, http://www.oracle.com/us/products/consulting/overview/index.html
#
############################################################
#Variables of the funcion:
file_name="$(echo $1)"
num_parameters="$(echo $2)"
col_names="$(echo $3)"
col_details="$(echo $4)"
vm_id=$5
add_object=$6

status=0
counter=0


arr_names=()
arr_details=()

create_arrays(){
  IFS=',' read -ra ADDR <<< "$col_names"
  for i in "${ADDR[@]}"; do
      arr_names+=("$i")
  done

  IFS=',' read -ra ADDR <<< "$col_details"
  for i in "${ADDR[@]}"; do
      arr_details+=("$i")
  done
  len=${#arr_details[@]}
  lines=$((len / num_parameters))
  status=1
}

all_info(){
  for (( i=0; i<$lines; i++ ))
  do
    for (( j=0; j<$num_parameters;j++ ))
    do
      detail+='"'${arr_names[$j]}'":'
      if [ $j -eq $((num_parameters-1)) ]
      then
        detail+='"'${arr_details[$counter]}'"'
      else
        detail+='"'${arr_details[$counter]}'",'
      fi
      ((counter++))
    done
    if [ $i -lt $((lines-1)) ]
    then
      detail+='},{'
    else
      detail+='}]}'
      echo $detail > $file_name
    fi
  done
}

create_jsonFile(){
  if [ $add_object -eq 0 ]
  then
    detail="$(echo '{"'$vm_id'":[{')"
    all_info
  else
    echo
    detail="$(cat $file_name |rev |cut -c 2- |rev)"
    detail+=',"'$vm_id'":[{'
    all_info
  fi

}

create_arrays
if [ $status -eq 1 ]
then
  create_jsonFile
fi
#python -m json.tool $file_name
