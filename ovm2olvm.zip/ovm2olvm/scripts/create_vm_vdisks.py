import os
import json
import sys
import logging

#Parameters
#Target Directory:
target=sys.argv[1]
#log File:
log=sys.argv[2]
#VM ID
VM_id=sys.argv[3]
#VM name
vm_name=sys.argv[4]
#Manager server
mngr_srv=sys.argv[5]
#Password
pswd=sys.argv[6]

logging.basicConfig(level = logging.INFO, filename = log)
obj = json.load(open(target+"/ovm2olvm/json_files/vdisks_info.json"))

print("     Creating Virtual Disks ... ")
logging.info("     Creating Virtual Disks ...")

            
for i in obj [VM_id]:
    print("        Creating vdisk: "+i['vdisk_name'])
    logging.info("       Creating vdisk: "+i['vdisk_name'])
    os.system("python scripts/create_olvm_vdisk.py "+vm_name+" "+mngr_srv+" "+pswd+" "+i['vdisk_size']+" "+i['vdisk_name']+" "+i['vdisk_id']+" "+target+" "+log)
    
f = open("/tmp/ovm2olvm_vm_vdisks_creation_status.txt", "w+")
f.write("1")
f.close()

