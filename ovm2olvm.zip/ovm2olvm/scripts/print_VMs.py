import os
import json
import sys

#Variables
#json File:
file=sys.argv[1]
#Option to print
option=sys.argv[2]
#status of the operations:
status=0
#Selected reporsiory by the user:
repo_selected_id=''

#Arrays:
VMs_id=[]
VMs_name=[]

def fill_arrays():
    i=0
    with open(file) as json_file:
        data = json.load(json_file)
        for p in data ['vms']:
            VMs_id.append(p['VM_uuid'])
            VMs_name.append(p['VM_Name'])
            i += 1

def print_vms_info():
    if option == 0:
        print("Vms to be migrated: ")
    else:
        print("List of VMs to be imported: ")
    print('')
    print("|===========================================================================================|")
    print("|                                              VMs                                          |")
    print("|===========================================================================================|")
    print("| N.| VM ID                            | VM Name                                            |")
    print("|-------------------------------------------------------------------------------------------|")
    items=len(VMs_id)
    for i in range (items):
        if i > 0:
            print("|-------------------------------------------------------------------------------------------|")
        print('|'+'%3s' % (i+1)+'|'+'%-33s' % (VMs_id[i])+' | '+'%-50s' % (VMs_name[i])+' |')
    print("|===========================================================================================|")
    return i+1

def list_vms():
    choose=0
    status=0
    if option == 0:
        while status < 1:
            i=print_vms_info()
            print('')
            try:
                choose = int(raw_input('Select an option:\n1- To migrate all the listed VMs.\n2- To choose the VMs to be migrated.\n'))
            except ValueError:
                os.system('clear')
                print('Error!!:  you choose a none valid option.')
                print('Please choose a correct number.')
                print('')
            else:
                if choose > 0 and choose <= 2:
                    status=1
                    f = open("/tmp/ovm2olvm_vm_chosen.txt", "w+")
                    f.write(str(choose))
                    f.close()
                else:
                    os.system('clear')
                    print('Error!!:  you choose a none valid option.')
                    print('Please choose a correct number.')
                    print('')
    else:
        i=print_vms_info()
        print('')
        status=1
        while status==1:
            try:
                choose = raw_input('Insert "y" to import the entire list or n to Choose the VMs from the list:  \n')
            except ValueError:
                os.system('clear')
                print('Error!!:  you choose a none valid option.')
                print('')
            else:
                if choose == "y" or choose == "Y":
                    status=0
                    f = open("/tmp/ovm2olvm_vm_chosen.txt", "w+")
                    f.write(str("1"))
                    f.close()
                else:
                    if choose == "n" or choose == "N":
                        status=0
                    else:
                        os.system('clear')
                        print('Error!!:  Insert "y" or "n" to continue.')
                        print('')
 
if os.path.exists(file): 
    fill_arrays()
    list_vms()
else:
    f = open("/tmp/ovm2olvm_vm_chosen.txt", "w+")
    f.write(str("2"))
    f.close()
    print(" [Error] File "+file+" Does not exists!")
