#!/usr/bin/env bash

# Name          : create_repository_jsonFile.sh
# Author        : carlos.gamboa@oracle.com
# Version       : 1.0
# Copyright     : GPLv2
# Description   : This script is use to creat the json file of all the repositories
# Usage         : ./create_repository_jsonFile.sh
#
# Disclaimer           :
#
#Keep in mind that this is not part of an Oracle solution, hence its customization is not supported.
#Oracle support is not responsible for maintaining, troubleshooting, nor supporting this script.
#
#If you consider this sample script suitable to be used as a solution but require customization, we rather recommend that you engage with Oracle ACS.
#
#Oracle Consulting Services, http://www.oracle.com/us/products/consulting/overview/index.html
#
############################################################
#Variables in the script
#File name:
file_name=$1
#log file:
log=$2
#Lists to pass the information to the mkJson script
repository_titles="$(echo "repo_id,repo_name,repo_mount_point,repo_type,repo_is_mounted,repo_size,repo_free_space")"
repository_info="$(echo " ")"

is_mounted='0'
status='0'

repo_id_="$(ovs-agent-db dump_db repository|grep alias|cut -d ':' -f1|cut -d "'" -f 2)"
################################

build_lists(){
  echo 'Building list of repositories...' >> $log
  echo >> $log
  for i in $(echo $repo_id_)
  do
    echo 'Building repository: '$i >> $log
    repository_info+=$i','
    repository_info+=`ovs-agent-db dump_db repository|grep $i|grep alias|cut -d ':' -f3|cut -d "'" -f 2`','
    repository_info+=`ovs-agent-db dump_db repository|grep $i|grep mount_point|cut -d ':' -f2|cut -d "'" -f 2`','
    repository_info+=`ovs-agent-db dump_db repository|grep $i -A 1|grep filesystem|cut -d ':' -f2|cut -d "'" -f 2`','
    is_mounted="$(df|grep $i|wc -l)"
    repository_info+=$is_mounted','
    if [ $is_mounted -eq 1 ]
    then
      repository_info+=`df|grep $i|awk '{print $1}'`','
      repository_info+=`df|grep $i|awk '{print $3}'`','
    else
      repository_info+='0,'
      repository_info+='0,'
    fi
  done
  status='1'
}

build_json_file(){
  echo '' >> $log
  echo 'Building json file of repositories...' >> $log
  echo '' >> $log
  status=$(/bin/bash scripts/mk_json_file.sh $file_name 7 "repositories" $repository_titles $repository_info $log)
  if [[ $status == '1' ]]
  then
    status='1'
  else
    status='0'
  fi
}

if [ -f scripts/mk_json_file.sh ]
then
  build_lists
  if [[ $status == '1' ]]
  then
    status='0'
    build_json_file
    if [[ $status == '1' ]]
    then
      echo '[OK] Repositories created correctly.' >> $log
      echo '---------------------------------------' >> $log
      echo 1
    else
      echo 0
    fi
  fi
else
  echo '[Error] The file scripts/mk_json_file.sh does not exist!! stopping process!' >> $log
  echo 0
fi
