#!/usr/bin/env bash

# Name          : create_vNICs_jsonFile.sh
# Author        : carlos.gamboa@oracle.com
# Version       : 1.0
# Copyright     : GPLv2
# Description   : This script is use to creat the json file of all the vNICs in the VMs
# Usage         : ./create_vNICs_jsonFile.sh
#
# Disclaimer           :
#
#Keep in mind that this is not part of an Oracle solution, hence its customization is not supported.
#Oracle support is not responsible for maintaining, troubleshooting, nor supporting this script.
#
#If you consider this sample script suitable to be used as a solution but require customization, we rather recommend that you engage with Oracle ACS.
#
#Oracle Consulting Services, http://www.oracle.com/us/products/consulting/overview/index.html
#
############################################################
#Variables in the script
#File name:
file_name=$1
#log file:
log=$2
#vm.cfg path
vm_path=$3
#Lists to pass the information to the mkJson script
vNICs_titles="$(echo "vnic_mac,vnic_device,vnic_bridge")"
vNICs_info="$(echo " ")"


#function to collect all the information:
run(){
	#Get the vNICs from the vm.cfg
	vNICs="$(egrep 'vif =' $vm_path|cut -d '[' -f2|cut -d ']' -f 1)"
	char=$(echo $vNICs|wc -c)
	i=0
	j=0
	#If equals to 3 means there is not network configured
	if [ $char == '3' ]
	then
		echo ' [Info]: No NICs detected skipping this process...' >>$log
	else
		while [ $i -lt 1 ]
		do
			#get the vNIC
			vNICs_i="$(echo $vNICs|cut -d ',' -f1|cut -d "'" -f2)"
			#get the mac address
			vNIC_mac="$(echo $vNICs_i|cut -d '=' -f2)"
			echo "  Collecting data for vNIC: eth$j   mac:  $vNIC_mac" >> $log
			vNICs_info+=$vNIC_mac','
			vNICs_info+='eth'$j','
			((j++))
			#insert the collected information
			#vNICs_i="$(echo $vNICs|cut -d ',' -f2)"
			vNIC_bridge="$(echo $vNICs|cut -d ',' -f2|cut -d '=' -f2|cut -d "'" -f1)"
			vNICs_info+=$vNIC_bridge

			#check if there is more vNICs in the vm.cfg file
			vNICs="$(echo $vNICs|cut -d ',' -f3-)"
			#if not
			if [ -z "$vNICs" ]
			then
				#get out of the while
				i=1
			#if not
			else
				#just add a ,
				vNICs_info+=','
			fi
			#get the VM id
			vm_id="$(echo $vm_path |cut -d '/' -f6)"

			#If the file_name does not exist
			if [ -f $file_name ]
			then
				#call the script to create the json file
				/bin/bash scripts/mk_vdisk_json_file.sh $file_name 3 $vNICs_titles $vNICs_info $vm_id 1
			else
				#call the script to add an object
				/bin/bash scripts/mk_vdisk_json_file.sh $file_name 3 $vNICs_titles $vNICs_info $vm_id 0
			fi
		done
	fi
}

run
