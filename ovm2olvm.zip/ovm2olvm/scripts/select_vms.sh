#!/usr/bin/env bash
#
# Name          : select_vms.sh
# Author        : carlos.gamboa@oracle.com
# Version       : 1.0
# Copyright     : GPLv2
# Description   : This script is used to Select the VMs that customer wants to migrate
#
# Disclaimer           :
#
#Keep in mind that this is not part of an Oracle solution, hence its customization is not supported.
#Oracle support is not responsible for maintaining, troubleshooting, nor supporting this script.
#
#If you consider this sample script suitable to be used as a solution but require customization, we rather recommend that you engage with Oracle ACS.
#
#Oracle Consulting Services, http://www.oracle.com/us/products/consulting/overview/index.html
#
############################################################
#Variables of the script:
#Json file for the VMs:
target=$1
#log file:
log=$2
#Target File systems

continue=0
#Array to the VMs name and id


#To store the list of VMs:
list_of_names=''
list_of_ids=''


fill_arrays(){
  status=0
  if [ -f $target/ovm2olvm/json_files/VMs_info.json ]
  then
    list_of_names="$(python -m json.tool $target/ovm2olvm/json_files/VMs_info.json |grep VM_Name|cut -d ":" -f 2|cut -d '"' -f 2)"
    list_of_ids="$(python -m json.tool $target/ovm2olvm/json_files/VMs_info.json |grep VM_uuid|cut -d ":" -f 2|cut -d '"' -f 2)"
    echo "Names: $list_of_names" >> $log
    echo "IDS: $list_of_ids" >> $log
    status=1
  else
    echo "[Error]: File: $target/ovm2olvm/json_files/VMs_info.json does not exist!!!" >> $log
  fi
}

remove_vdisks(){
  VM=$1
  ID=$2
  echo "    Removing vdisks from VM: $VM" >> $log
  python scripts/remove_item_json_file.py $ID $target/ovm2olvm/json_files/vdisks_info.json 2
  echo "    Vdisks has been removed from json file!" >> $log
}

remove_vnics(){
  VM=$1
  ID=$2
  echo "    Removing vNics from VM: $VM" >> $log
  python scripts/remove_item_json_file.py $ID $target/ovm2olvm/json_files/vNICs_info.json 2
  echo "    vNics has been removed from json file!" >> $log
}

remove_vm(){
  VM=$1
  ID=$2
  echo "    Removing VM: $VM" |tee -a $log
  python scripts/remove_item_json_file.py $ID $target/ovm2olvm/json_files/VMs_info.json 1
  echo "    VM has been removed from json file!" >> $log
}

get_an_answer(){
  VM=$1
  ID=$2
  #clear
  echo '-------------' |tee -a $log
  continue=0
  #Display the information to the customer
  echo "  Do you want to migrate VM: $VM?" | tee -a $log
  echo ""
  while [ $continue -eq 0 ]
  do
    read -p "    Type y to yes or n to no: " choose
    #If the option is not between the parameters
    if [[ $choose == 'y' ]] || [[ $choose == "Y" ]] || [[ $choose == "n" ]] || [[ $choose == "N" ]]
    then
      continue=1
      echo "    Answer: $choose" >> $log
      if [[ $choose == "n" ]] || [[ $choose == "N" ]]
      then
        remove_vdisks $VM $ID
        remove_vnics $VM $ID
        remove_vm $VM $ID
        delete=($ID)
        list_of_ids=("${list_of_ids[@]/$delete}")
        deleted_vm=true
      fi
    #show error message
    else
      echo "[Error]: Insert y or n"
      echo ""
    fi
  done
}

collect_VMs(){
  j=0
  for i in ${list_of_names[@]}
  do
    deleted_vm=false
    arr=($list_of_ids)
    get_an_answer $i ${arr[$j]}
    if [ $deleted_vm == false ]
    then
      ((j++))
    fi
  done
  echo '-------------' >> $log
  status=1
}

fill_arrays
if [ $status -eq 1 ]
then
  collect_VMs
  if [ $status -eq 1 ]
  then
    echo 1 > /tmp/removed_vms.sts
  fi
fi
