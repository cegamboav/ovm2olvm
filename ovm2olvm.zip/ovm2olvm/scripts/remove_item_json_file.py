import os
import json
import sys

object=sys.argv[1]
file=sys.argv[2]
source=sys.argv[3]


def remove_VM():
    with open(file) as json_file:
        obj = json.load(json_file)
        #obj = json.load(open(file))
        j=0
        for i in obj ['vms']:
            if i['VM_uuid'] == object:
                del obj['vms'][j]
                break
            else:
                j += 1
    with open(file, 'w') as data_file:
        data = json.dump(obj, data_file)

def remove_vdisk_vnics():
    obj = json.load(open(file))
    for i in obj:
      if i == object:
        del obj[str(i)]
        break

    with open(file, 'w') as data_file:
        data = json.dump(obj, data_file)

#If source is 1 means VMs json file
if source == '1':
    remove_VM()
#If is 2 is all the vdisks or vnics of a VM
elif source == '2':
    remove_vdisk_vnics()
