#!/usr/bin/env bash
# Name          : select_olvm_manager_server_name.sh
# Author        : carlos.gamboa@oracle.com
# Version       : 1.0
# Copyright     : GPLv2
# Description   : This script is to collect the correct manager server name or IP Address
# Usage         : ./select_olvm_manager_server_name.sh
#
# Disclaimer           :
#
#Keep in mind that this is not part of an Oracle solution, hence its customization is not supported.
#Oracle support is not responsible for maintaining, troubleshooting, nor supporting this script.
#
#If you consider this sample script suitable to be used as a solution but require customization, we rather recommend that you engage with Oracle ACS.
#
#Oracle Consulting Services, http://www.oracle.com/us/products/consulting/overview/index.html
#
############################################################
#Variables of the script:
#log file:
log=$1
#Manager name:
manager_name=`hostname`

while [[ $continue -eq 0 ]]
do
	echo "Selecting Manager Server Name or IP:"|tee -a $log
	echo ""|tee -a $log
	echo "Do you want to use this name: "|tee -a $log
	echo ""|tee -a $log
	echo $manager_name|tee -a $log
	echo ""|tee -a $log
	read -p "Please select y or n: " choose
	echo ""|tee -a $log
	#If the option is not between the parameters
	if [[ $choose == 'y' ]] || [[ $choose == 'Y' ]] || [[ $choose == 'n' ]] || [[ $choose == 'N' ]]
	then
		continue=1
		status="1"
		if [[ $choose == 'y' ]] || [[ $choose == 'Y' ]] 
		then
			echo "[OK] Manager Name or IP Set."| tee -a $log
			echo '---------------------------------------' |tee -a $log
		fi
	#show error message
	else
	  echo "[Error]: You need to choose between y or n!!!!"|tee -a $log
	  echo ""|tee -a $log
	fi
done
if [[ $choose == 'n' ]] || [[ $choose == 'n' ]]
then
	status="0"
	continue_2=0
	while [ $continue_2 -eq 0 ]
	do
		read -p "Insert the IP Address or name of the Manager: " choose_2
		echo |tee -a $log
		echo "We are going to use the name of the server:"|tee -a $log
		echo ""|tee -a $log
		echo $choose_2|tee -a $log
		echo ""|tee -a $log
		read -p "Select y or n: " choose_3
		#If the option is not between the parameters
		if [[ $choose_3 == 'y' ]] || [[ $choose_3 == 'Y' ]]
		then
			continue_2=1
			status="1"
			manager_name=$choose_2
			echo "[OK] Manager Name or IP Set."| tee -a $log
			echo '---------------------------------------' |tee -a $log
		#show error message
		elif [[ $choose_3 == 'n' ]] || [[ $choose_3 == 'N' ]]
		then
			echo ""
			continue_2=0
		else
		  echo "[Error]: You need to choose between y or n!!!!"|tee -a $log
		  echo ""|tee -a $log
		fi
	done
fi
if [[ $status == '1' ]]
then
	echo "$manager_name" > /tmp/olvm_server_name.txt
fi