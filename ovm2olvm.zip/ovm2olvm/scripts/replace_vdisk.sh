#!/usr/bin/env bash

# Name          : runApplication.sh
# Author        : carlos.gamboa@oracle.com
# Version       : 1.0
# Copyright     : GPLv2
# Description   : This script is used to replace the vdisk create to the one from ovm
# Usage         : ./replace_vdisk
#
# Disclaimer           :
#
#Keep in mind that this is not part of an Oracle solution, hence its customization is not supported.
#Oracle support is not responsible for maintaining, troubleshooting, nor supporting this script.
#
#If you consider this sample script suitable to be used as a solution but require customization, we rather recommend that you engage with Oracle ACS.
#
#Oracle Consulting Services, http://www.oracle.com/us/products/consulting/overview/index.html
#
############################################################
Id_1=$1
Id_2=$2
target=$3
log=$4

replace_vdisk(){
	path=$(find $target/*/images -name $Id_1)
	echo "       Proceed to replace vdisk $Id_1 by the original disk $Id_2" >> $log
	disk_file=$(ls $path/|egrep -v 'lease|meta')
	mv $target/vdisks/$Id_2 $path/$disk_file
	chown vdsm:kvm $path/$disk_file
	echo "          Disk Moved correctly." >> $log
}


if [ -f $target/vdisks/$Id_2 ]
then
	replace_vdisk
else
	echo "[Error] The vdisk id: $Id_2 does not exist in $target/vdisks/" >> $log
	echo "Skipping cration of this vdisk ...." >> $log
fi