import os
import json
import sys

file=sys.argv[1]
dictionary=sys.argv[2]
object=sys.argv[3]

#with open(file) as data_file:
    #data = json.load(data_file)
    #for element in data:
    #        del element[object]

array = []

with open(file) as json_file:
    data = json.load(json_file)
    for p in data [dictionary]:
        #print(p['VM_uuid'])
        array.append(p[object.vdisk_path])


#json_data = json.loads(file)

#for i in xrange(len(json_data)):
 # if(json_data[i]["id"] == "mark"):
#    del json_data[i]
#    break

# animals list

# 'guinea pig' is appended to the animals list

# Updated animals list
print('VM List: ', array)
