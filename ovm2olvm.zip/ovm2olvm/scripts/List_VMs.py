import os
import json
import sys

#Variables
#json File:
target=sys.argv[1]
#Platform
platform=sys.argv[2]
#status of the operations:
status=0
#Selected reporsiory by the user:
repo_selected_id=''

file=target+'/ovm2olvm/json_files/VMs_info.json'

#Arrays:
VMs_id=[]
VMs_name=[]

def fill_arrays():
    i=0
    with open(file) as json_file:
        data = json.load(json_file)
        for p in data ['vms']:
            VMs_id.append(p['VM_uuid'])
            VMs_name.append(p['VM_Name'])
            i += 1

def print_vms_info():
    print("VMs in the Selected repository: ")
    print('')
    print("|===========================================================================================|")
    print("|                                              VMs                                          |")
    print("|===========================================================================================|")
    print("| N.| VM ID                            | VM Name                                            |")
    print("|-------------------------------------------------------------------------------------------|")
    items=len(VMs_id)
    for i in range (items):
        if i > 0:
            print("|-------------------------------------------------------------------------------------------|")
        print('|'+'%3s' % (i+1)+'|'+'%-33s' % (VMs_id[i])+' | '+'%-50s' % (VMs_name[i])+' |')
    print("|===========================================================================================|")
    return i+1

def list_vms():
    os.system('clear')
    choose=0
    status=0
    while status < 1:
        i=print_vms_info()
        print('')
        try:
            choose = int(raw_input('Select an option:\n1- To migrate all the listed VMs.\n2- To choose the VMs to be migrated.\n'))
        except ValueError:
            os.system('clear')
            print('Error!!:  you choose a none valid option.')
            print('Please choose a correct number.')
            print('')
        else:
            if choose > 0 and choose <= 2:
                status=1
                f = open("/tmp/ovm2olvm_vm_chosen.txt", "a")
                f.write(str(choose))
                f.close()
            else:
                os.system('clear')
                print('Error!!:  you choose a none valid option.')
                print('Please choose a correct number.')
                print('')

fill_arrays()
if platform == 0:
    list_vms()
else:
    list_olvm_vms()
