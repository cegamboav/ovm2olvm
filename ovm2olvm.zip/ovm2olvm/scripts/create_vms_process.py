import os
import json
import sys
import logging

#Parameters
#json File:
target=sys.argv[1]
#log File:
log=sys.argv[2]
#manager Name
manager_name=sys.argv[3]
#Password
paswd=sys.argv[4]
#Cluster
clst=sys.argv[5]
#Network Name
ntwk_name=sys.argv[6]


#Variables:
#status of the operations:
status=0
#Selected reporsiory by the user:
repo_selected_id=''
#The status of the vm creation:
status="0"
#The status of the vms_vdisks creation:
status_2="0"

logging.basicConfig(level = logging.INFO, filename = log)

file=target+'/ovm2olvm/json_files/VMs_info.json'

#Arrays:
VMs_id=[]
VMs_name=[]
VMs_cpu=[]
VMs_mem=[]
VM_description=[]
VMs_ver=[]


def fill_arrays():
    i=0
    with open(file) as json_file:
        data = json.load(json_file)
        for p in data ['vms']:
            VMs_id.append(p['VM_uuid'])
            VMs_name.append(p['VM_Name'])
            VMs_cpu.append(p['VM_vcpu'])
            VMs_mem.append(p['VM_Memory'])
            VM_description.append(p['VM_description'])
            i += 1

def create_vms():
    items=len(VMs_id)
    for i in range (items):
        f = open("/tmp/ovm2olvm_vm_creation_status.txt", "w+")
        f.write("0")
        f.close()
        logging.info("  Processing VM: "+(VMs_name[i])+"   ...")
        print('   Processing VM: '+(VMs_name[i])+"   ...")
        os.system("python scripts/create_olvm_vm.py "+manager_name+" "+paswd+" "+VMs_name[i]+" "+clst+" "+VMs_mem[i]+" "+VMs_cpu[i]+" '"+VM_description[i]+"'")
        print('')
        f = open("/tmp/ovm2olvm_vm_creation_status.txt", "r")
        status=(f.read())
        if status == "1":
            os.system('sleep 5')
            logging.info(" ")
            f = open("/tmp/ovm2olvm_vm_vdisks_creation_status.txt", "w+")
            f.write("0")
            f.close()
            os.system("python scripts/create_vm_vdisks.py "+target+" "+log+" "+VMs_id[i]+" "+VMs_name[i]+" "+manager_name+" "+paswd)
            f = open("/tmp/ovm2olvm_vm_vdisks_creation_status.txt", "r")
            status_2=(f.read())
            if status_2 == "1":
                f = open("/tmp/ovm2olvm_vm_vnic_creation_status.txt", "w+")
                f.write("0")
                f.close()
                os.system("python scripts/create_vm_vnics.py "+target+" "+log+" "+VMs_id[i]+" "+VMs_name[i]+" "+" "+manager_name+" "+paswd+" "+ntwk_name)
            else:
                break
            print("   [OK] VM "+(VMs_name[i])+" has been created correctly.")
            logging.info("   [OK] VM "+(VMs_name[i])+" has been created correctly.")
            print("   -----------")
            logging.info("   -----------")
        else:
            print("===================================================================")
            #break
        print("--------")
        print(" ")
    print('The script has completed succesfully.')
    return i+1

fill_arrays()
create_vms()