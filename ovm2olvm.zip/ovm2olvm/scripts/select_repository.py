import os
import json
import sys

#Variables
#json File:
file=sys.argv[1]
#status of the operations:
status=0
#Selected reporsiory by the user:
repo_selected_id=''

#Arrays:
repo_id=[]
repo_name=[]
repo_type=[]

def fill_arrays():
    i=0
    with open(file) as json_file:
        data = json.load(json_file)
        for p in data ['repositories']:
            if p['repo_is_mounted'] == '1':
                repo_id.append(p['repo_id'])
                repo_name.append(p['repo_name'])
                repo_type.append(p['repo_type'])
            i += 1

def print_repositories():
    print("Repositories in the OVS Server: ")
    print('')
    print("|==========================================================================================|")
    print("|                                        Repositories                                      |")
    print("|==========================================================================================|")
    print("| N.| Repository ID                    | Repository Name                          | Type   |")
    print("|------------------------------------------------------------------------------------------|")
    items=len(repo_id)
    for i in range (items):
        if i > 0:
            print("|------------------------------------------------------------------------------------------|")
        print('|'+'%3s' % (i+1)+'|'+'%-33s' % (repo_id[i])+' | '+'%-40s' % (repo_name[i])+' | '+'%-6s' % (repo_type[i])+' |')
    print("|==========================================================================================|")
    return i+1

def choose_repo():
    os.system('clear')
    choose=0
    status=0
    while status < 1:
        i=print_repositories()
        print('')
        try:
            choose = int(raw_input('Select a Repository between 1 and '+str(i)+':   '))
        except ValueError:
            os.system('clear')
            print('Error!!:  you choose a none valid option.')
            print('Please choose a correct number.')
            print('')
        else:
            if choose > 0 and choose <= i:
                status=1
                repo_selected_id=repo_id[choose-1]
                f = open("/tmp/ovm2olvm_repo_chosen.txt", "a")
                f.write(repo_selected_id)
                f.close()
            else:
                os.system('clear')
                print('Error!!:  you choose a none valid option.')
                print('Please choose a correct number.')
                print('')

fill_arrays()
choose_repo()
