#!/usr/bin/env bash
#
# Name          : create_jsonFiles.sh
# Author        : carlos.gamboa@oracle.com
# Version       : 1.0
# Copyright     : GPLv2
# Description   : This all the other scripts to create json_files
# Usage         : ./create_jsonFiles.sh
#
#
# Disclaimer           :
#
#Keep in mind that this is not part of an Oracle solution, hence its customization is not supported.
#Oracle support is not responsible for maintaining, troubleshooting, nor supporting this script.
#
#If you consider this sample script suitable to be used as a solution but require customization, we rather recommend that you engage with Oracle ACS.
#
#Oracle Consulting Services, http://www.oracle.com/us/products/consulting/overview/index.ovm2olv
#
#
#Variables of the script
#To control the status of the script:
status=0
#The target repository
target=$1
#log file:
log=$2


#function to run the scripts:
run_all(){
  #Collect the repositories information:
  echo '' >> $log
  echo 'Calling create repository jsonFile Function...' >> $log
  echo '' >> $log
  if [ -f scripts/create_repository_jsonFile.sh ]
  then
    status=$(/bin/bash scripts/create_repository_jsonFile.sh $target/ovm2olvm/json_files/repositories.json $log)
    if [ $status -eq 1 ]
    then
      echo 'Calling create Server jsonFile Function...' >> $log
      echo '' >> $log
      status=0
      if [ -f scripts/create_srv_jsonFile.sh ]
      then
        status=$(/bin/bash scripts/create_srv_jsonFile.sh $target $log)
        if [ $status -eq 1 ]
        then
          echo '' >> $log
          echo 1
        else
          echo 0
        fi
      else
        echo '[Error] The file scripts/create_srv_jsonFile.sh does not exist!! stopping process!' >> $log
        echo 0
      fi
    else
      echo 0
    fi
  else
    echo '[Error] The file scripts/create_repository_jsonFile.sh does not exist!! stopping process!' >> $log
    echo 0
  fi
}

run_all
