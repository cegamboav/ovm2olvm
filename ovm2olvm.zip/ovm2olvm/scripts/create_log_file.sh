#!/usr/bin/env bash

{ # try
  #create the log file with the date
  echo /tmp/ovm2olvm_`date +"%Y%m%d%h%s"`.log > /tmp/log_file.txt
  touch `cat /tmp/log_file.txt`
  echo '1'
} || { # catch
    echo '0'
}
