import ovirtsdk4 as sdk
import ovirtsdk4.types as types
import sys

#Variables
manager_name=sys.argv[1]
pswd=sys.argv[2]

# Create the connection to the server:
connection = sdk.Connection(
    url='https://'+manager_name+'/ovirt-engine/api',
    username='admin@internal',
    password=pswd,
    ca_file='scripts/ca.pem',
)

nws_service = connection.system_service().networks_service()

nws = nws_service.list()

for nw in nws:
    print (nw.name)
connection.close()
