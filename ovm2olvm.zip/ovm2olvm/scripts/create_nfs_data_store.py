import ovirtsdk4 as sdk
import ovirtsdk4.types as types
import os
import sys

manager_name=sys.argv[1]
pswd=sys.argv[2]
hname=sys.argv[3]
adrs=sys.argv[4]
pth=sys.argv[5]

# Create the connection to the server:
connection = sdk.Connection(
    url='https://'+manager_name+'/ovirt-engine/api',
    username='admin@internal',
    password=pswd,
    ca_file='scripts/ca.pem',
)

# Get the reference to the storage domains service:
sds_service = connection.system_service().storage_domains_service()

# Create a new NFS storage domain:
sd = sds_service.add(
    types.StorageDomain(
        name='mydata',
        description='My data',
        type=types.StorageDomainType.DATA,
        host=types.Host(
            name=hname,
        ),
        storage=types.HostStorage(
            type=types.StorageType.NFS,
            address=adrs,
            path=pth,
        ),
    ),
)

# Wait until the storage domain is unattached:

sd_service = sds_service.storage_domain_service(sd.id)
while True:
    #time.sleep(5)
    os.system('sleep 5')
    sd = sd_service.get()
    if sd.status == types.StorageDomainStatus.UNATTACHED:
        f = open("/tmp/nfs_ds.txt", "a")
        f.write(str(sd.id))
        f.close()
        break
connection.close()