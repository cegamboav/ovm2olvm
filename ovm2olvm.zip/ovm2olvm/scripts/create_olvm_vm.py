#!/usr/bin/env python
import ovirtsdk4 as sdk
import ovirtsdk4.types as types
import sys

manager_name=sys.argv[1]
pswd=sys.argv[2]
VM=sys.argv[3]
clst=sys.argv[4]
MEM_=sys.argv[5]
CPU=sys.argv[6]
DESCRIPTION=sys.argv[7]

CPU_=int(CPU)
MEM=int(MEM_)
MB=1048576

# Create the connection to the server:
connection = sdk.Connection(
    url='https://'+manager_name+'/ovirt-engine/api',
    username='admin@internal',
    password=pswd,
    ca_file='scripts/ca.pem',
)

# Get the reference to the "vms" service:
vms_service = connection.system_service().vms_service()

#Set CPUs amount
cpu = types.CpuTopology(cores=CPU_, sockets=1)

try:
    vms_service.add(
        types.Vm(
            name=VM,
            cluster=types.Cluster(
                name=clst,
            ),
            template=types.Template(
                name='Blank',
            ),
            memory=MEM*MB,
            cpu=types.Cpu(topology=cpu),
            description=DESCRIPTION,
            os=types.OperatingSystem(boot=types.Boot(devices=[types.BootDevice.HD])
            ),
        )
    )
    f = open("/tmp/ovm2olvm_vm_creation_status.txt", "w+")
    f.write("1")
    f.close()
except:
    print("[Error] Please check the error.")
    print("===================================================================")
    print("Unexpected error:", sys.exc_info()[0])
    raise
    
    
    


# Close the connection to the server:
connection.close()