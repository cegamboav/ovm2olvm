#!/usr/bin/env bash

# Name          : general_review_ovsserver.sh
# Author        : carlos.gamboa@oracle.com
# Version       : 1.0
# Copyright     : GPLv2
# Description   : This script is used to check the OVS Server
# Usage         : ./general_review_ovsserver.sh
#
# Disclaimer           :
#
#Keep in mind that this is not part of an Oracle solution, hence its customization is not supported.
#Oracle support is not responsible for maintaining, troubleshooting, nor supporting this script.
#
#If you consider this sample script suitable to be used as a solution but require customization, we rather recommend that you engage with Oracle ACS.
#
#Oracle Consulting Services, http://www.oracle.com/us/products/consulting/overview/index.html
#
############################################################
#Variables of the script
#1 to ok, and 0 for none ok
status=0
#log file:
log=$1

#function to verify the version of the server
check_ovs_version(){
  echo '** Checking OVS Server Version...' >> $log
  echo '---------------------------------------' >> $log
  if [ -f /etc/ovs-release ]
  then
    #Get the OVS Server Version
    version="$(cat /etc/ovs-release |awk '{print $5}')"
    #if it's in 3.4.6 change the status to 1
    if [ $version == '3.4.6' ]
    then
      status=1
      echo '[OK] The version is Correct: '$version >> $log
      echo '---------------------------------------' >> $log
    else
      echo "[Error]: Current version:"| tee -a $log
      cat /etc/ovs-release| tee -a $log
      echo "Please upgrade the server to the latest version!"| tee -a $log
      echo '---------------------------------------' >> $log
    fi
  else
    echo "[Error]: It's impossible to determine the OVS Server Version, the file /etc/ovs-release does not exist!!!"| tee -a $log
    echo '---------------------------------------' >> $log
  fi
}

#function to check if the OVS Server has running VMs on it:
check_running_vms(){
  echo '** Checking Running VMs in the OVS Server ...' >> $log
  echo '' >> $log
  vms="$(xm list|egrep -v 'Domain-0|Name'|wc -l)"
  if [ $vms == '0' ]
  then
    status=1
    echo '[OK] No VMs running in the OVS Server' >> $log
    echo '---------------------------------------' >> $log
  else
    echo '[Error]: The Server has VMs running on it, please stop all of them to continue with the process.' >> $log
    echo 'Stopping the process!' >> $log
    echo '---------------------------------------' >> $log
    status=2
  fi
}

#Function to check all in the OVS Server
check_all(){
  #first check the OVS Version:
  check_ovs_version
  #If the status is 1 continue with the others validation
  if [ $status -eq 1 ]
  then
    #******OJO aqui descomentar estos 2:
    #status=0
    #check_running_vms
    if [ $status -eq 1 ]
    then
      echo 1
    #If not, terminate the process
    else
      echo 0
    fi
  #If not, terminate the process
  else
    echo 0
  fi
}

check_all
