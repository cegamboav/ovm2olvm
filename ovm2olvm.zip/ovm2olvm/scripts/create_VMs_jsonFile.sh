#!/usr/bin/env bash

# Name          : create_VMs_jsonFile.sh
# Author        : carlos.gamboa@oracle.com
# Version       : 1.0
# Copyright     : GPLv2
# Description   : This script create a json file with the information of the VMs

#Variables in the script
#Lists to pass the information to the mkJson script
VM_titles="$(echo "VM_Name,VM_uuid,VM_on_reboot,VM_boot_order,VM_Memory,VM_Max_Memory,VM_vcpu,VM_max_vcpu,VM_HA,VM_on_crash,VM_os_type,VM_os_version,VM_domain_type,VM_description")"
VM_info="$(echo " ")"

status=0
first_line=0
#Repository chosen by the customer
repository=$1
#Target repository
target=$2
#log file:
log=$3
#Variable to know if the VM has valid quantity of vdisks:
num_vdisks=0
#Number of VMs process
proceed_vms=0



################################

#function to check if the VM have vdisks
check_vdisks(){
	#Set the status to 0
	status=0
	#Set the VM path
	vm_path=$1
	#Get the disks configuration file
	disks="$(grep 'disk =' $vm_path|cut -d '[' -f2|cut -d ']' -f 1)"
	#Get how many characters it has
	char=$(echo $disks|wc -c)
	#If have more than 1 characters, means the VM has disks configured
	if [ $char -gt 1 ]
	then
		#Check if exist any vdisk in the line:
		vdisks=$(echo $disks|egrep '.img'|wc -l)
		#If is equals to 0
		if [ $vdisks -eq 0 ]
		then
			#Message to the customer
			echo "  [Warning]: This VM do not have vdisks, skipping from the process..." >> $log
		else
			#status goes to 1
			status=1
		fi
	else
		#Message to the customer
		echo "  [Warning]: The VM does not have valid virtual disks attached, skipping the process." >> $log
	fi
}

check_description_name(){
  nstatus=0
  des=$description
  description=$(echo $des|sed 's/\//_/g'|sed 's/\./_/g'|sed 's/\[/_/g'|sed 's/\]/_/g'|sed 's/{/_/g'|sed 's/}/_/g')
  nstatus=1
}

fill_list(){
  status=0
  #Start to fill the list:
  VM_info+=$vm_name','
  VM_info+=$i','
  VM_info+=`egrep "on_reboot =" /OVS/Repositories/$repository/VirtualMachines/$i/vm.cfg|cut -d "=" -f 2|sed 's/ //g'|sed 's/'\''//g'`','
  bootloader="$(egrep "bootloader =" /OVS/Repositories/$repository/VirtualMachines/$i/vm.cfg|wc -l)"
  if [ $bootloader == '0' ]
  then
    VM_info+="$(egrep "boot =" /OVS/Repositories/$repository/VirtualMachines/$i/vm.cfg|grep -v on_reboot|cut -d "=" -f 2|sed 's/ //g'|sed 's/'\''//g')"
  else
    VM_info+='c'
  fi
  VM_info+=','
  VM_info+=`egrep "memory =" /OVS/Repositories/$repository/VirtualMachines/$i/vm.cfg|cut -d "=" -f 2|sed 's/ //g'|sed 's/'\''//g'`','
  max_men="$(egrep "maxmem =" /OVS/Repositories/$repository/VirtualMachines/$i/vm.cfg|wc -l)"
  if [ $max_men == '0' ]
  then
    VM_info+=`egrep "memory =" /OVS/Repositories/$repository/VirtualMachines/$i/vm.cfg|cut -d "=" -f 2|sed 's/ //g'|sed 's/'\''//g'`','
  else
    VM_info+=`egrep "maxmem =" /OVS/Repositories/$repository/VirtualMachines/$i/vm.cfg|cut -d "=" -f 2|sed 's/ //g'|sed 's/'\''//g'`','
  fi
  VM_info+=`egrep 'vcpus =' /OVS/Repositories/$repository/VirtualMachines/$i/vm.cfg|grep -v maxvcpus|cut -d "=" -f 2|sed 's/ //g'|sed 's/'\''//g'`','
  max_cpu="$(egrep "maxvcpus =" /OVS/Repositories/$repository/VirtualMachines/$i/vm.cfg|wc -l)"
  if [ $max_cpu == '0' ]
  then
    VM_info+=`egrep 'vcpus =' /OVS/Repositories/$repository/VirtualMachines/$i/vm.cfg|grep -v maxvcpus|cut -d "=" -f 2|sed 's/ //g'|sed 's/'\''//g'`','
  else
    VM_info+=`egrep "maxvcpus =" /OVS/Repositories/$repository/VirtualMachines/$i/vm.cfg|cut -d "=" -f 2|sed 's/ //g'|sed 's/'\''//g'`','
  fi
  HA="$(egrep "OVM_high_availability =" /OVS/Repositories/$repository/VirtualMachines/$i/vm.cfg|cut -d "=" -f 2)"
  if [ $HA == 'False' ]
  then
    VM_info+='0,'
  else
    VM_info+='1,'
  fi
  VM_info+=`egrep "on_crash =" /OVS/Repositories/$repository/VirtualMachines/$i/vm.cfg|cut -d "=" -f 2|sed 's/ //g'|sed 's/'\''//g'`','
  VM_info+=`egrep "guest_os_type =" /OVS/Repositories/$repository/VirtualMachines/$i/vm.cfg|cut -d "=" -f 2|sed 's/ //g'|sed 's/'\''//g'`','
  VM_info+=`egrep "OVM_os_type =" /OVS/Repositories/$repository/VirtualMachines/$i/vm.cfg|cut -d "=" -f 2|sed 's/ //g'|sed 's/'\''//g'`','
  VM_info+=`egrep "OVM_domain_type =" /OVS/Repositories/$repository/VirtualMachines/$i/vm.cfg|cut -d "=" -f 2|sed 's/ //g'|sed 's/'\''//g'`','
  description="$(egrep "OVM_description =" /OVS/Repositories/$repository/VirtualMachines/$i/vm.cfg|cut -d "=" -f 2|sed 's/ //g'|sed 's/'\''//g')"
  if [ -z "$description" ]
  then
    VM_info+='null'
  else
    #To check if the name do not have special characters
    check_description_name
    if [ $nstatus -eq 1 ]
    then
      VM_info+=$description
    else
      VM_info+='null'
    fi
  fi
  status=1
}

build_lists(){
	echo "** Processing VMs in the Repository: "$repository >> $log
	echo ''>> $log
	#get the VMs from the Repository
	list_vms="$(ls /OVS/Repositories/$repository/VirtualMachines/)"
	#To know if there are VMs:
	len=$(echo "$list_vms" | wc -l)
	echo "Number of VMs in the Repository: $len" >> $log
	echo ''>> $log
	#If there are at least 1 VM file there:
	if [ $len -gt 0 ]
	then
		#Run over the list
		for i in $(echo $list_vms)
		do
			if [ $first_line -eq 0 ]
			then
				first_line=1
			else
				VM_info+=','
			fi
			#Check if the vm.cfg file exists:
			if [ -f /OVS/Repositories/$repository/VirtualMachines/$i/vm.cfg ]
			then
				#Get the VM name:
				vm_name=`grep OVM_simple_name /OVS/Repositories/$repository/VirtualMachines/$i/vm.cfg|cut -d "=" -f 2|sed 's/ //g'|sed 's/'\''//g'`

				echo "Processing VM: "$vm_name >> $log
				#Check if this VM file contains vdisks
				check_vdisks /OVS/Repositories/$repository/VirtualMachines/$i/vm.cfg
				if [ $status -eq 1 ]
				then
					num_vdisks=''
					num_vdisks=$(/bin/bash scripts/create_vdisks_jsonFile.sh $target/ovm2olvm/json_files/vdisks_info.json $log /OVS/Repositories/$repository/VirtualMachines/$i/vm.cfg)
					if [ $num_vdisks -gt 0 ]
					then
						fill_list
						#If all goes good
						if [ $status -eq 1 ]
						then
							#call to create
							status=$(/bin/bash scripts/create_vNICs_jsonFile.sh $target/ovm2olvm/json_files/vNICs_info.json $log /OVS/Repositories/$repository/VirtualMachines/$i/vm.cfg)
							((proceed_vms++))
						fi
					else
						echo "  [Warning]: The VM does not have valid vdisks, skipping the process." >> $log
						first_line=0
					fi
					echo '===========' >> $log
					#If the VM do not have vdisks then do not add the ","
				else
				  first_line=0
				fi
			else
				echo "  [Error]: No vm.cfg file for the vm number:  $i">> $log
				first_line=0
			fi
		done
		echo '===========' >> $log
		echo "Total of proceeded VMs: $proceed_vms" >> $log
		status=1
	else
		#a error message is sent to the customer
		echo '[Error]: The repository does not have any VMs configured!!' >> $log
		status=0
	fi
}

build_json_file(){
  echo '-----------------------------------' >> $log
  echo '** Creating JSON files for the VMs ...' >> $log
  echo '' >> $log
  status=$(/bin/bash scripts/mk_json_file.sh $target/ovm2olvm/json_files/VMs_info.json 14 "vms" $VM_titles $VM_info)
  echo '[OK] Finish to create the VMs files...' >> $log
  status=1
}

#function to remove old json files if they exist:
remove_files(){
  echo '' >> $log
  echo '** Removing old JSON files...' >> $log
  echo '' >> $log
  rm -f $target/ovm2olvm/json_files/VMs_info.json
  rm -f $target/ovm2olvm/json_files/vdisks_info.json
  rm -f $target/ovm2olvm/json_files/vNICs_info.json
  echo '[OK] Old JSON files removed.' >> $log
  echo '' >> $log
}

#checking if the script to create the json file exist:
if [ -f scripts/create_vdisks_jsonFile.sh ]
then
	#Checking if the script to create the vnics exist:
	if [ -f scripts/create_vNICs_jsonFile.sh ]
	then
		#proceed to remove old files
		remove_files
		#then proceed to build the list of vms
		build_lists
		#if all goes good
		if [ $status -eq 1 ]
		then
			status=0
			#proceed to build the json files:
			build_json_file
			if [ $status -eq 1 ]
			then
				echo 1
			else
				echo 0
			fi
		fi
	else
		#show error
		echo "[Error]: The file scripts/create_vNICs_jsonFile.sh does not exist!! Exit process" >> $log
	fi
else
	#show error
	echo "[Error]: The file scripts/create_vdisks_jsonFile.sh does not exist!! Exit process" >> $log
fi
