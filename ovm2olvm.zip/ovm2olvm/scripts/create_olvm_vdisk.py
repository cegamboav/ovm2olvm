import ovirtsdk4 as sdk
import ovirtsdk4.types as types
import os
import sys

vm_name=sys.argv[1]
manager_server=sys.argv[2]
paswd=sys.argv[3]
vdisk_size=sys.argv[4]
vdisk_alias=sys.argv[5]
vdisk_id=sys.argv[6]
target=sys.argv[7]
log=sys.argv[8]

vds=int(vdisk_size)

connection = sdk.Connection(
   url='https://'+manager_server+'/ovirt-engine/api',
   username='admin@internal',
   password=paswd,
   ca_file='scripts/ca.pem',
)


vms_service = connection.system_service().vms_service()
vm = vms_service.list(search='name='+vm_name)[0]
disk_attachments_service =vms_service.vm_service(vm.id).disk_attachments_service()
disk_attachment = disk_attachments_service.add(
    types.DiskAttachment(
        disk=types.Disk(
            format=types.DiskFormat.COW,
            provisioned_size=vds*1073741824,
            alias=vdisk_alias,
            storage_domains=[
                types.StorageDomain(
                    name='mydata',
                ),
            ],
        ),
        interface=types.DiskInterface.VIRTIO,
        bootable=False,
        active=True,
    ),
)
disks_service = connection.system_service().disks_service()
disk_service = disks_service.disk_service(disk_attachment.disk.id)
while True:
    os.system('sleep 5')
    disk = disk_service.get()
    if disk.status == types.DiskStatus.OK:
        os.system('/bin/bash scripts/replace_vdisk.sh '+disk.id+" "+vdisk_id+" "+target+" "+log)
        break
connection.close()