#!/usr/bin/env bash

# Name          : runApplication.sh
# Author        : carlos.gamboa@oracle.com
# Version       : 1.0
# Copyright     : GPLv2
# Description   : This script is used to start the migration process from OLVM perspective
# Usage         : ./OLVM_Manager_main_process.sh
#
# Disclaimer           :
#
#Keep in mind that this is not part of an Oracle solution, hence its customization is not supported.
#Oracle support is not responsible for maintaining, troubleshooting, nor supporting this script.
#
#If you consider this sample script suitable to be used as a solution but require customization, we rather recommend that you engage with Oracle ACS.
#
#Oracle Consulting Services, http://www.oracle.com/us/products/consulting/overview/index.html
#
############################################################
#Variables of the script:
manager_name=''
admin_passwd=''
server_name=''
adrs=''
pth=''
network_name=''
dc_name=''
clst_name=''


start_vms_migration(){
	echo "Start the VMs migration ..." |tee -a $log
	echo ""|tee -a $log
	python scripts/create_vms_process.py $target $log $manager_name $admin_passwd $clst_name $network_name
}

attach_st_to_dc(){
	echo "Attaching the NFS Storage to data Center ..."
	echo ""|tee -a $log
	echo 0 > /tmp/nfs_ds.txt
	python scripts/attach_storage_to_data_center.py $manager_name $admin_passwd $dc_name
	dc_status=$(cat /tmp/nfs_ds.txt)
	if [[ $nfs_status == '0' ]]
	then
		echo "[Error] The attaching has failed."|tee -a $log
	else
		echo "[OK] The Storage Domain has been attached correctly."|tee -a $log
		echo '---------------------------------------' |tee -a $log
		start_vms_migration
		
	fi
}

start_migration_process(){
	python scripts/print_VMs.py $target/ovm2olvm/json_files/VMs_info.json 1
	echo ""|tee -a $log
	echo "Creating NFS data store ..."|tee -a $log
	echo ""|tee -a $log
	echo 0 > /tmp/nfs_ds.txt
	python scripts/create_nfs_data_store.py $manager_name $admin_passwd $server_name $adrs $pth
	nfs_status=$(cat /tmp/nfs_ds.txt)
	if [[ $nfs_status == '0' ]]
	then
		echo "[Error] The creation of the NFS Storage Domain fails."|tee -a $log
	else
		echo "[OK] The NFS Storage Domain has been correctly created"|tee -a $log
		echo ""|tee -a $log
		echo "Its name is mydata"|tee -a $log
		echo '---------------------------------------' |tee -a $log
		attach_st_to_dc
	fi
}

select_cluster(){
	clst_=$(python scripts/list_olvm_cluster.py $manager_name $admin_passwd)
	#Fill te array
	for i in $(echo $clst_)
	do
	  clsts_+=(""$i"")
	done
	num_clstrs=${#clsts_[@]}
	if [ $num_clstrs > 0 ]
	then
		echo|tee -a $log
		continue=0
		while [ $continue -eq 0 ]
		do
			j=1
			echo "Checking Clusters created in the OLVM Manager"|tee -a $log
			echo "Please select the Cluster to work with in the migration process:"|tee -a $log
			echo ""|tee -a $log
			for i in ${clsts_[@]}
			do
			  echo $j".  "$i|tee -a $log
			  ((j++))
			done
			echo ""|tee -a $log
			read -p "Choose a Cluster between 1 and "$num_clstrs": " choose
			echo |tee -a $log
			#If the option is not between the parameters
			if [[ $choose -gt 0 ]] && [[ $choose -le $num_clstrs ]]
			then
			  continue=1
			  status="1"
			  clst_name=${clsts_[$choose-1]}
			  echo "The Cluster chosen is: $clst_name"|tee -a $log
			  echo ""|tee -a $log
			  echo "[OK] Cluster has been chosen."| tee -a $log
			  echo '---------------------------------------' |tee -a $log
			#show error message
			else
			  echo "[Error]: You need to choose a number between 1 and "$num_clstrs"!!!!"|tee -a $log
			  echo ""|tee -a $log
			fi
		done
	else
		echo "[Error] No Clusters detected, stopping the process"|tee -a $log
		status='0'
	fi
	if [[ $status == '1' ]]
    then
		start_migration_process
	fi
}

select_dc(){
	dc_=$(python scripts/list_olvm_dcs.py $manager_name $admin_passwd)
	#Fill te array
	for i in $(echo $dc_)
	do
	  dcs_+=(""$i"")
	done
	num_dcs=${#dcs_[@]}
	if [ $num_dcs > 0 ]
	then
		echo|tee -a $log
		continue=0
		while [ $continue -eq 0 ]
		do
			j=1
			echo "Checking Data Centers created in the OLVM Manager"|tee -a $log
			echo "Please select the Data Center to work with in the migration process:"|tee -a $log
			echo ""|tee -a $log
			for i in ${dcs_[@]}
			do
			  echo $j".  "$i|tee -a $log
			  ((j++))
			done
			echo ""|tee -a $log
			read -p "Choose a Data Center between 1 and "$num_dcs": " choose
			echo |tee -a $log
			#If the option is not between the parameters
			if [[ $choose -gt 0 ]] && [[ $choose -le $num_dcs ]]
			then
			  continue=1
			  status="1"
			  dc_name=${dcs_[$choose-1]}
			  echo "The Data Center chosen is: $dc_name"|tee -a $log
			  echo ""|tee -a $log
			  echo "[OK] Data Center has been chosen."| tee -a $log
			  echo '---------------------------------------' |tee -a $log
			#show error message
			else
			  echo "[Error]: You need to choose a number between 1 and "$num_dcs"!!!!"|tee -a $log
			  echo ""|tee -a $log
			fi
		done
	else
		echo "[Error] No Data Centers detected, stopping the process"|tee -a $log
		status='0'
	fi
	if [[ $status == '1' ]]
    then
		select_cluster
	fi
}

select_network(){
	network_=$(python scripts/list_olvm_networks.py $manager_name $admin_passwd)
	#Fill te array
	for i in $(echo $network_)
	do
	  Ntwrk+=(""$i"")
	done
	num_ntwk=${#Ntwrk[@]}
	if [ $num_ntwk > 0 ]
	then
		echo|tee -a $log
		continue=0
		while [ $continue -eq 0 ]
		do
			j=1
			echo "Checking Networks created in the OLVM Manager"|tee -a $log
			echo "Please select the Network to work with in the migration process:"|tee -a $log
			echo ""|tee -a $log
			for i in ${Ntwrk[@]}
			do
			  echo $j".  "$i|tee -a $log
			  ((j++))
			done
			echo ""|tee -a $log
			read -p "Choose a Network between 1 and "$num_ntwk": " choose
			echo |tee -a $log
			#If the option is not between the parameters
			if [[ $choose -gt 0 ]] && [[ $choose -le $num_ntwk ]]
			then
			  continue=1
			  status="1"
			  network_name=${Ntwrk[$choose-1]}
			  echo "The Network chosen is: $network_name"|tee -a $log
			  echo ""|tee -a $log
			  echo "[OK] Network has been chosen."| tee -a $log
			  echo '---------------------------------------' |tee -a $log
			#show error message
			else
			  echo "[Error]: You need to choose a number between 1 and "$num_ntwk"!!!!"|tee -a $log
			  echo ""|tee -a $log
			fi
		done
	else
		echo "[Error] No Network detected, stopping the process"|tee -a $log
		status='0'
	fi
	if [[ $status == '1' ]]
    then
		select_dc
	fi
}

select_server_name(){
	servers=$(python scripts/list_olvm_servers.py $manager_name $admin_passwd)
	#Fill te array
	for i in $(echo $servers)
	do
	  Srvs+=(""$i"")
	done
	num_srv=${#Srvs[@]}
	if [ $num_srv > 0 ]
	then
		echo|tee -a $log
		continue=0
		while [ $continue -eq 0 ]
		do
			j=1
			echo "Checking Servers presented to OLVM Manager"|tee -a $log
			echo "Please select the server to work with in the migration process:"|tee -a $log
			echo ""|tee -a $log
			for i in ${Srvs[@]}
			do
			  echo $j".  "$i|tee -a $log
			  ((j++))
			done
			echo ""|tee -a $log
			read -p "Choose a Server between 1 and "$num_srv": " choose
			echo |tee -a $log
			#If the option is not between the parameters
			if [[ $choose -gt 0 ]] && [[ $choose -le $num_srv ]]
			then
			  continue=1
			  status="1"
			  server_name=${Srvs[$choose-1]}
			  echo "The server chosen is: $server_name"|tee -a $log
			  echo ""|tee -a $log
			  echo "[OK] Server name Chosen."| tee -a $log
			  echo '---------------------------------------' |tee -a $log
			#show error message
			else
			  echo "[Error]: You need to choose a number between 1 and "$num_srv"!!!!"|tee -a $log
			  echo ""|tee -a $log
			fi
		done
	else
		echo "[Error] No servers detected, stopping the process"|tee -a $log
		status='0'
	fi
	if [[ $status == '1' ]]
    then
		select_network
	fi
}

test_name_and_password(){
	echo "Verifying server name/IP and Password ..."|tee -a $log
	echo ""|tee -a $log
	test_=$(python scripts/test_name_passwd.py $manager_name $admin_passwd)
	if [[ $test_ == '0' ]]
	then
		echo "[OK] Manager name/IP and password verified correctly."|tee -a $log
		echo '---------------------------------------' |tee -a $log
		select_server_name
	else
		clear
		echo "[Error] The server name or password is wrong, please insert the data again."|tee -a $log
		echo ""|tee -a $log
		echo "Python error:"|tee -a $log
		echo ""|tee -a $log
		echo $test_|tee -a $log
		echo ""|tee -a $log
		echo "Collecting information again:"|tee -a $log
		echo""|tee -a $log
		confirm_manager_name
	fi
}

get_admin_password(){
	continue=0
	while [ $continue -eq 0 ]
	do
		echo "Collecting Admin Password"|tee -a $log
		echo ""
		read -p "Insert admin user password: " admin_passwd
		echo
		echo "Is this your correct password: "
		echo ""
		echo "$admin_passwd"
		echo ""
		read -p  "Select y or n: " choose
		echo |tee -a $log
		#If the option is not between the parameters
		if [[ $choose == 'y' ]] || [[ $choose == 'Y' ]] 
		then
			continue=1
			status="1"
			echo "[OK] Admin password set."| tee -a $log
			echo '---------------------------------------' |tee -a $log
	    elif [[ $choose == 'n' ]] || [[ $choose == 'N' ]]
	    then
			continue=0
		#show error message
		else
		  echo "[Error]: You need to choose between y or n!!!!"|tee -a $log
		  echo ""|tee -a $log
		fi
	done
	if [[ $status == '1' ]]
    then
		test_name_and_password
	fi
}

confirm_manager_name(){
	echo 0 > /tmp/olvm_server_name.txt
	/bin/bash scripts/select_olvm_manager_server_name.sh $log
	manager_name=$(cat /tmp/olvm_server_name.txt)
	if [[ $manager_name == '0' ]]
	then
		echo "[Error] No server name set!!!"
	else
		get_admin_password
	fi
}

select_nfs(){
  status='0'
  if [ -f scripts/select_nfs.sh ]
  then
    #select an NFS from the customer:
    /bin/bash scripts/select_nfs.sh $log 1
    status="$(cat /tmp/status.txt)"
    #If status 1 means the NFS is okay
    if [[ $status == '1' ]]
    then
      #create_target_structure
      echo "1"
	elif [[ $status == '2' ]]
	then
		echo "Setting Target, Address and Path ..." >> $log
		echo "" >> $log
		target=$(cat /tmp/target.txt)
		adrs=$(mount |egrep $target|awk '{print($1)}'|cut -d ':' -f 1)
		pth=$(mount |egrep $target|awk '{print($1)}'|cut -d ':' -f 2)
		echo "Address: $adrs and Path: $pth" >> $log
		echo "" >> $log
		echo "[OK] Address and Path set." >> $log
		echo "---------------------------------------">>$log
		echo ""|tee -a $log
		confirm_manager_name
    fi
  else
    echo "[Error]: File scripts/select_nfs.sh does not exist!!! Finishing the script..."| tee -a $log
  fi
}

create_log_file(){
  status=$(/bin/bash scripts/create_log_file.sh)
  #If it was create correctly
  if [[ $status == '1' ]]
  then
    log=`cat /tmp/log_file.txt`
    echo "[OK] Log file created "$log |tee $log
    echo '-----------------------------------'| tee -a $log
    select_nfs
  else
    echo "[Error]: The log file was not able to be created..."| tee -a $log
    echo "Stopping the program!"| tee -a $log
    echo '-----------------------------------'| tee -a $log
  fi
}

OLVM_Manager(){
  #create the Log file
  if [ -f scripts/create_log_file.sh ]
  then
    echo "** Creating log file ..."
    echo ""
    create_log_file
  else
    echo "[Error]: File scripts/create_log_file.sh does not exist!!! Finishing the script..."
  fi
}


OLVM_Manager