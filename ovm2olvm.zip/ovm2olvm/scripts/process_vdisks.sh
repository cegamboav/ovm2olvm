#!/usr/bin/env bash
#
# Name          : process_vdisks.sh
# Author        : carlos.gamboa@oracle.com
# Version       : 1.0
# Copyright     : GPLv2
# Description   : This script is used to convert the vdisks from raw format to qcow2
#
# Disclaimer           :
#
#Keep in mind that this is not part of an Oracle solution, hence its customization is not supported.
#Oracle support is not responsible for maintaining, troubleshooting, nor supporting this script.
#
#If you consider this sample script suitable to be used as a solution but require customization, we rather recommend that you engage with Oracle ACS.
#
#Oracle Consulting Services, http://www.oracle.com/us/products/consulting/overview/index.html
#
############################################################
#Variables of the script:
#Varaible to know the status of the process:
status=0
#The target Repository
target=$1
#Log file
log=$2
#option
opt=$3

#funcion to convert the disks
convert_disk(){
  _vdisk=$1
  _vname=$2
  if [ -f $_vdisk ]
  then
    echo "  Converting $_vdisk..." >>$log
    qemu-img convert -f raw -O qcow2 $_vdisk $target/vdisks/$_vname
    echo ''>>$log
  else
    echo "  [Error]: The file $_vdisk do not exist, skipping this process." >>$log
  fi
}

#function to just copy the vdisks into the new NFS device
just_copy_vdisks(){
  _vdisk=$1
  _vname=$2
  if [ -f $_vdisk ]
  then
    echo "  Copying $_vdisk..." >>$log
    cp $_vdisk $target/vdisks/$_vname
    echo ''>>$log
  else
    echo "  [Error]: The file $_vdisk do not exist, skipping this process." >>$log
  fi
}

#function to create array of vdisks
create_array(){
  status=0
  vdisks=$(python -m json.tool $target/ovm2olvm/json_files/vdisks_info.json|grep path|cut -d ':' -f 2|cut -d '"' -f 2)
  status=1
}

run_the_array(){
  status=0
  opt2=$1
  for i in ${vdisks[@]}
  do
    vname=$(echo $i|cut -d '/' -f 6)
    if [ $opt2 -eq 1 ]
    then
      convert_disk $i $vname
    else
      just_copy_vdisks $i $vname
    fi
  done
  status=1
}

create_array
if [ $status -eq 1 ]
then
  if [ $opt -eq 1 ]
  then
    run_the_array 1
  else
    run_the_array 2
  fi
fi
if [ $status -eq 1 ]
then
  echo 1
else
  echo 0
fi
