import ovirtsdk4 as sdk
import ovirtsdk4.types as types
import sys

#Variables
manager_name=sys.argv[1]
pswd=sys.argv[2]

# Create the connection to the server:
connection = sdk.Connection(
        url='https://'+manager_name+'/ovirt-engine/api',
        username='admin@internal',
        password=pswd,
        ca_file='scripts/ca.pem',
)


host_service = connection.system_service().hosts_service()
hosts = host_service.list()
for host in hosts:
  print host.name
connection.close()