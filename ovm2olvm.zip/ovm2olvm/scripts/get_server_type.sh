#!/usr/bin/env bash
#
# Name          : get_server_type.sh
# Author        : carlos.gamboa@oracle.com
# Version       : 1.0
# Copyright     : GPLv2
# Description   : This script verify if the server is OVS Server, OLVM Manager or another server
# Usage         : ./get_server_type.sh
#
#
# Disclaimer           :
#
#Keep in mind that this is not part of an Oracle solution, hence its customization is not supported.
#Oracle support is not responsible for maintaining, troubleshooting, nor supporting this script.
#
#If you consider this sample script suitable to be used as a solution but require customization, we rather recommend that you engage with Oracle ACS.
#
#Oracle Consulting Services, http://www.oracle.com/us/products/consulting/overview/index.html
#
#
know_server(){
  #to know if is an OVS Server
  srv="$(ls /etc/ovs-release 2>/dev/null|wc -l )"
  if (( $srv == "1" ))
  then
    echo 1
  else
    #to know if is the OLVM Manager
    srv="$(ls /usr/share/ovirt-engine/services/ovirt-engine/ovirt-engine.conf 2>/dev/null|wc -l)"
    if (( $srv == "1" ))
    then
      echo 2
    else
      echo 3
    fi
  fi
}

know_server
