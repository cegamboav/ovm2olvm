#!/usr/bin/env bash
#
# Name          : create_target_structure.sh
# Author        : carlos.gamboa@oracle.com
# Version       : 1.0
# Copyright     : GPLv2
# Description   : This script create a json file with the information of the repositories
# Usage         : ./create_target_structure.sh
#
#
# Disclaimer           :
#
#Keep in mind that this is not part of an Oracle solution, hence its customization is not supported.
#Oracle support is not responsible for maintaining, troubleshooting, nor supporting this script.
#
#If you consider this sample script suitable to be used as a solution but require customization, we rather recommend that you engage with Oracle ACS.
#
#Oracle Consulting Services, http://www.oracle.com/us/products/consulting/overview/index.html
#
#
#variables of the script:
#to store the target FS:
target=$1
#Log file:
log=$2
#To get the status of the process:
status=0

make_structure(){
	{ # try
		#create the directories structure in the file system
		echo "** Creating target directories...." >> $log
		mkdir -p $target/ovm2olvm/json_files/
		mkdir $target/vdisks/
		touch $target/status.txt
		echo >> $log
		echo '[OK] Directories created correctly.' >> $log
		echo '---------------------------------------' >> $log
		status=1
	} || { # catch
		status=0
	}
}

make_structure
if [ $status -eq 1 ]
then
  echo 1
else
  echo 0
fi
