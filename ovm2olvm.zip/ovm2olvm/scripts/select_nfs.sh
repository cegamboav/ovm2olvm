#!/usr/bin/env bash

# Name          : select_nfs.sh
# Author        : carlos.gamboa@oracle.com
# Version       : 1.0
# Copyright     : GPLv2
# Description   : This script is use to make the customer select an Nfs fs to be used as target
#                 of the OLVM movement
# Usage         : ./select_nfs.sh
#
# Disclaimer           :
#
#Keep in mind that this is not part of an Oracle solution, hence its customization is not supported.
#Oracle support is not responsible for maintaining, troubleshooting, nor supporting this script.
#
#If you consider this sample script suitable to be used as a solution but require customization, we rather recommend that you engage with Oracle ACS.
#
#Oracle Consulting Services, http://www.oracle.com/us/products/consulting/overview/index.html
#
############################################################
#Variables of the script:
#Array to store the Nfs fss:
Nfss=()
#List of the Nfs fss mounted:
Nfsfs="$(mount|egrep 'type nfs'|egrep -v 'type nfsd'|awk '{print $3}')"
#To store the amount of items in the array
num_fs=0
#Variable to choose the number of the fs
j=1
#variable to know if has to continue:
continue=0
#Variable to know ths status of the process 1=good 0=bad
status=0
#Log file:
log=$1
#environment
environment=$2
############################################################

#function to check if the fs is empty:
is_empty(){
  if [[ $environment -eq 0 ]]
	then
		#check the fs to see if is empty
		echo '----------------------------' |tee -a $log
		echo '** Checking if the File System '$1' is empty...'|tee -a $log
		echo |tee -a $log
		empty="$(find $1 -maxdepth 0 -empty -exec echo 'empty' \;)"
		if [[ $empty == "empty" ]]
		then
		status=1
		echo |tee -a $log
		echo '[OK] The File System: '$1' It is empty.'|tee -a $log
		echo '---------------------------------------' |tee -a $log
		else
		if [[ $environment -eq 0 ]]
		then
			echo '' |tee -a $log
			echo "[Error]: the File System $1 is not empty, please use an empty File System..." |tee -a $log
			echo "Stopping the process!"|tee -a $log
			echo '---------------------------------------' >> $log
			echo |tee -a $log
			status=0
		else
			status=1
			echo |tee -a $log
			echo '[OK] The File System: '$1' It is not empty.'|tee -a $log
			echo '---------------------------------------' |tee -a $log
		fi
		fi
	else
		status=1
	fi
}

#Check if the fs is in use:
is_used(){
  echo '** Checking if the File System is in use...'|tee -a $log
  echo |tee -a $log
  used="$(lsof $1|wc -l)"
  if [ $used == '0' ]
  then
    echo '[OK] The File System is not in use.'|tee -a $log
    echo '---------------------------------------'|tee -a $log
    status=1
  else
    echo '' |tee -a $log
    echo "[Error]: the File System $1 is in use..." |tee -a $log
    echo "Stopping the process!"|tee -a $log
    echo '---------------------------------------' >> $log
    status=0
  fi
}

#Function to let the customer choose the Nfs to be the target in the migration:
choose_fs(){
  echo|tee -a $log
  echo|tee -a $log
  while [ $continue -eq 0 ]
  do
    j=1
    #Display the information to the customer
	if [[ $environment -eq 0 ]]
	then
		echo "File Systems in the OVS Server"|tee -a $log
		echo "Please select the one to be the target in the migration:"|tee -a $log
		echo
	else
		echo "Checking NFS File Systems presented to OLVM Manager"|tee -a $log
		echo "Please select the File System target in the migration:"|tee -a $log
		echo ""|tee -a $log
	fi	
    for i in ${Nfss[@]}
    do
		echo $j".  "$i|tee -a $log
		((j++))
    done
    echo ""|tee -a $log
    read -p "Choose a File System between 1 and "$num_fs": " choose
    echo |tee -a $log
    #If the option is not between the parameters
    if [[ $choose -gt 0 ]] && [[ $choose -le $num_fs ]]
    then
		continue=1
		status=1
    #show error message
    else
		echo "[Error]: You need to choose a number between 1 and "$num_fs"!!!!"|tee -a $log
		echo ""|tee -a $log
    fi
  done

}

#Fill te array
for i in $(echo $Nfsfs)
do
  Nfss+=(""$i"")
done


## get length of $Nfss array
num_fs=${#Nfss[@]}

if [ $num_fs > 0 ]
then
	#first we choose the target fs:
	choose_fs
	#If the status is 1
	if [ $status -eq 1 ]
	then
		#Then check if is empty:
		status=0
		is_empty ${Nfss[$choose-1]}
		#if is empty
		if [ $status -eq 1 ] && [[ $environment -eq 0 ]]
		then
			status=0
			#check if is used:
			is_used ${Nfss[$choose-1]}
			if [ $status -eq 1 ]
			then
				echo ${Nfss[$choose-1]} > /tmp/target.txt
				echo 1 > /tmp/status.txt
				echo "[OK] The file system to be used in the migration is: ${Nfss[$choose-1]}" >> $log
			else
				echo 0 > /tmp/status.txt
			fi
		else
			if [[ $environment -eq 1 ]]
			then
				echo "Checking the status of the information ..."|tee -a $log
				echo
				estado="$(cat ${Nfss[$choose-1]}/status.txt)"
				if [[ $estado == "ok" ]]
				then
					echo ${Nfss[$choose-1]} > /tmp/target.txt
					echo |tee -a $log
					echo "File system to be used is: ${Nfss[$choose-1]}"|tee -a $log
					echo ""|tee -a $log
					echo '[OK] The Information looks good.'|tee -a $log
					echo '---------------------------------------' |tee -a $log
					echo 2 > /tmp/status.txt
				else
					echo "[Error] The file ${Nfss[$choose-1]}/status.txt is empty"
					echo 0 > /tmp/status.txt
				fi
				
			else
				echo 0 > /tmp/status.txt
			fi 
		fi
	else
		echo 0 > /tmp/status.txt
	fi
else
	echo 0 > /tmp/status.txt
fi
