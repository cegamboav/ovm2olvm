import ovirtsdk4 as sdk
import ovirtsdk4.types as types
import os
import sys

vm_name=sys.argv[1]
manager_server=sys.argv[2]
paswd=sys.argv[3]
vnic_name=sys.argv[4]
network_name=sys.argv[5]
log=sys.argv[6]


connection = sdk.Connection(
   url='https://'+manager_server+'/ovirt-engine/api',
   username='admin@internal',
   password=paswd,
   ca_file='scripts/ca.pem',
)


vms_service = connection.system_service().vms_service()
vm = vms_service.list(search='name='+vm_name)[0]

# Locate the service that manages the network interface cards of the
# virtual machine:
nics_service = vms_service.vm_service(vm.id).nics_service()

# Use the "add" method of the network interface cards service to add the
# new network interface card:
nics_service.add(
    types.Nic(
        name=vnic_name,
        description=vnic_name,
        network=types.Network(
            name=network_name,
        ),
    ),
)


#print("Network interface '%s' added to '%s'." % (nic.name(), vm.name()))
connection.close()