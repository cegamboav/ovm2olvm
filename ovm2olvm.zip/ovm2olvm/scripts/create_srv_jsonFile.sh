#!/usr/bin/env bash

# Name          : create_srv_jsonFile.sh
# Author        : carlos.gamboa@oracle.com
# Version       : 1.0
# Copyright     : GPLv2
# Description   : This script is used to create the server json file
# Usage         : ./create_srv_jsonFile.sh
#
#
#Keep in mind that this is not part of an Oracle solution, hence its customization is not supported.
#Oracle support is not responsible for maintaining, troubleshooting, nor supporting this script.
#
#If you consider this sample script suitable to be used as a solution but require customization, we rather recommend that you engage with Oracle ACS.
#
#Oracle Consulting Services, http://www.oracle.com/us/products/consulting/overview/index.html
#
############################################################
#Variables of the script:
#The ourput json file:
target=$1
#Log file:
log=$2
#To store the ovs server version:
$version
#lists to store the server information
srv_titles="$(echo "s_name,s_version,s_status")"
srv_info="$(echo " ")"
#To check the status of the process:
status=0

#Function to create the json file of the server
create_json_file(){
  echo 'Building the server json file...' >> $log
  echo >> $log
  #recopilate the information
  srv_info+=`hostname`','
  version="$(cat /etc/ovs-release |awk '{print $5}')"
  srv_info+=$version','
  if [[ $version == '3.4.6' ]]
  then
    srv_info+='1'
  else
    srv_info+='0'
  fi
  #call the file to creat the json file:
  status=$(/bin/bash scripts/mk_json_file.sh $target/ovm2olvm/json_files/ovs_server.json 3 "servers" $srv_titles $srv_info $log)
  if [ $status -eq 1 ]
  then
    echo 'Server JSON File has been created correctly..                 [OK]' >> $log
    echo '---------------------------------' >> $log
    status=1
  else
    status=0
  fi
}

if [ -f scripts/mk_json_file.sh ]
then
  create_json_file
  if [ $status -eq 1 ]
  then
    echo 1
  else
    echo 0
  fi
else
  echo '[Error] The file scripts/mk_json_file.sh does not exist!! stopping process!' >> $log
  echo 0
fi
