#!/usr/bin/env bash

# Name          : runApplication.sh
# Author        : carlos.gamboa@oracle.com
# Version       : 1.0
# Copyright     : GPLv2
# Description   : This script is used to start the migration process
# Usage         : ./runApplication.sh
#
# Disclaimer           :
#
#Keep in mind that this is not part of an Oracle solution, hence its customization is not supported.
#Oracle support is not responsible for maintaining, troubleshooting, nor supporting this script.
#
#If you consider this sample script suitable to be used as a solution but require customization, we rather recommend that you engage with Oracle ACS.
#
#Oracle Consulting Services, http://www.oracle.com/us/products/consulting/overview/index.html
#
############################################################
#Variables of the script:
log=''
status='0'
repository=''

OVS_Server(){
  clear
  #create the Log file
  if [ -f scripts/OVS_Server_main_process.sh ]
  then
    echo "** Calling OVS Server Main Process ..."
    echo ""
    /bin/bash scripts/OVS_Server_main_process.sh $log
  else
    echo "[Error]: File scripts/OVS_Server_main_process.sh does not exist!!! Finish program..."
  fi
}

OLVM_Manager(){
  clear
  #create the Log file
  if [ -f scripts/OLVM_Manager_main_process.sh ]
  then
    echo "** Calling OLVM Manager Main Process ..."
    echo ""
    /bin/bash scripts/OLVM_Manager_main_process.sh $log
  else
    echo "[Error]: File scripts/OLVM_Manager_main_process.sh does not exist!!! Finish program..."
  fi
}

no_server(){
  echo "[Error]: Sorry, but this looks like is not a OVM Server nor OLVM Manager Server."| tee -a $log
  echo "Stopping script"| tee -a $log
}

#function to call all the functions to validate the servers
start_validation(){
  #Get the server type
  if [ -f scripts/get_server_type.sh ]
  then
    serv_code=$(/bin/bash scripts/get_server_type.sh)
    #If is 1 this is OVS Server
    if [ $serv_code == "1" ]
    then
      #call the OVS Server script
      OVS_Server
    #If is 2 this is the manager OLVM
    elif [ $serv_code == "2" ]
    then
      #Call the OLVM manager server
      OLVM_Manager
    #If not the script is running over a different kind of server
    else
      #Call the no server function
      no_server
    fi
  else
    echo "[Error]: File scripts/get_server_type.sh does not exist!!! Finish program..."
  fi
}


start_validation
